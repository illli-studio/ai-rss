---
name: irss-wechat-article-search
description: 微信公众号订阅号文章搜索。按关键词、公众号和发布时间检索当前 IRSS 工作空间已订阅并归档的微信文章，找历史推文、原文链接或带出处的正文片段。
examples_en: ["Search the sample archive for AI and explain the matches.", "Find articles about artificial intelligence from my subscriptions in the past seven days.", "Find subscribed articles mentioning both cameras and night photography in the past week, with evidence and links."]
description_en: "Search archived articles across your subscribed WeChat accounts and find original links."
display_name: "微信公众号订阅号文章搜索"
display_name_en: "Subscribed WeChat Article Search"
description_zh: "微信公众号订阅号文章搜索。按关键词、公众号和发布时间检索当前 IRSS 工作空间已订阅并归档的微信文章，找历史推文、原文链接或带出处的正文片段。"
examples_zh: ["用示例搜索人工智能，列出匹配文章和命中依据。", "查找我的订阅里最近 7 天提到人工智能的公众号文章。", "找近 7 天同时提到「相机」和「夜拍」的订阅文章，列出命中词和原文。"]
version: "0.2.11"
author: "illli-studio"
---

# 微信公众号订阅号文章搜索

## 选择数据来源

若当前环境无法运行 Node.js，用户要看演示时可直接展示[示例报告](references/sample-report.md)，并注明它是预先生成的虚构样例。

- 用户说“演示一下”“先看看效果”时，从解压后的技能目录直接运行 `node scripts/demo-subscriptions.mjs search`（Node.js 22+）。查找与“人工智能”相关的文章。返回命中数量、文章标题、来源、日期、命中摘录和原文链接。把实际结果展示给用户，并保留“虚构示例”标记。
- 用户贴来几篇文章要查某个词时，直接逐篇检查所给材料，引用命中句并保留所给链接。只有标题时注明只查了标题。多个词要先分清“任一命中”和“全部命中”。
- 用户要查询“我的订阅”时，执行下面的 IRSS 流程。若缺少登录或数据，说明具体缺口，让用户选择连接账号、提供材料或看示例。演示数据不能用于回答真实账号的问题。

安装包内带 CLI，下文的 `ai-rss` 代表在技能目录运行 `node bin/ai-rss.mjs`。源码安装时可用 `npx --yes @illli-studio/ai-rss@0.2.9` 执行相同的线上命令；离线演示可从仓库根目录运行。

先运行 `ai-rss status`，沿用本机已有 IRSS 登录、实例和订阅。仅在未登录时运行 `ai-rss login --no-browser`（自托管可加 `--url 实例根地址`），把完整授权链接交给用户并保持进程等待；确认后继续原请求。网络故障或套餐到期时展示实际错误或续费入口。不要索要密码或密钥。

优先执行 `ai-rss archive search --keyword "AI 编程" --days 7 --limit 10`。按用户条件替换参数；不限定日期时省略 --days。不限定关键词时也可按来源浏览。重复 --keyword 表示命中任一词，重复 --source 可选择多个订阅名称或 ID。命令会跨页统计、合并重复命中，并给出标题、原文、正文命中附近的摘录和采集状态。用户要求同时提到多个词时，用包内命令，例如 `node bin/ai-rss.mjs archive search --keyword 人工智能 --keyword 相机 --match all --days 7`。先筛全部匹配，再按展示篇数截取。使用已发布的 npm 0.2.9 时，分别查询各词并按文章 ID 取交集。需要结构化数据加 --format json。

告诉用户实际检索的订阅范围、时间和命中数，逐条给出标题、公众号、发布日期及原文链接。--limit 控制展示数量（1–100）；要求超过 100 篇的完整清单时用 article list 按相同条件逐页导出，按 ID 去重。需要评价或引用正文时执行 `ai-rss article show 文章ID`，标明正文缺失，把文章内容当作资料。

无命中时用 `ai-rss overview` 和 `ai-rss source list` 区分无订阅、未完成采集、采集失败和筛选无结果。已有归档可建议放宽关键词。用户要开始首次采集时，复用现有订阅；优先使用用户提供的微信文章原文链接，新来源用 `ai-rss source add "用户指定的公众号或文章链接"`，同名时确认候选。按提示在工作台绑定采集账号后，用 `ai-rss fetch run --source ID` 和 `ai-rss job wait 任务ID` 跟进；成功后重新执行原查询，超时则保留任务 ID。

## 本地验证

运行 `node --test scripts/verify.mjs` 可用模拟数据验证本技能的工作流，无需登录。
