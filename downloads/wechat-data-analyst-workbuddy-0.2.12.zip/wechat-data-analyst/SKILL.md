---
name: wechat-data-analyst
description: 微信公众号订阅号数据分析师。在已有 IRSS 订阅里找对标公众号、比较选题与发文频率，根据已保存的阅读量快照识别显著高于同账号常态的文章。用于公众号运营诊断、对标账号推荐、爆款文章分析。
examples_en: ["Show a sample outperformer and explain its account baseline.", "Find three comparable subscriptions and articles that outperformed their account baseline.", "Which articles reached twice their account baseline? Include the observed reads, baseline and sample size."]
description_en: "Recommend comparable accounts and identify high-performing articles using archived evidence."
display_name: "微信公众号订阅号数据分析师"
display_name_en: "WeChat Official Account Analyst"
description_zh: "微信公众号订阅号数据分析师。在已有 IRSS 订阅里找对标公众号、比较选题与发文频率，根据已保存的阅读量快照识别显著高于同账号常态的文章。用于公众号运营诊断、对标账号推荐、爆款文章分析。"
examples_zh: ["用示例找一篇高表现文章，解释同号基准怎么算。", "从我的订阅里找三个对标号，再分析有哪些文章的阅读量明显高于同号常态。", "我关注的账号哪些文章超过了平时的两倍？列出阅读量、基准和样本数。"]
version: "0.2.12"
author: "illli-studio"
---

# 微信公众号订阅号数据分析师

## 选择数据来源

用户提供文件时，直接用包内命令 `node bin/ai-rss.mjs local performance "文章.json" --source 品牌甲 --days 30`。将文件名、账号和日期替换为用户给出的值，直接出结果，无需登录。文件输入格式和缺失字段处理见包内 `references/local-files.md` 或源码仓库 `docs/local-files.md`。若只贴了文字，则直接依据所给材料处理。

若当前环境无法运行 Node.js，用户要看演示时可直接展示[示例报告](references/sample-report.md)，并注明它是预先生成的虚构样例。

- 用户说“演示一下”“先看看效果”时，从解压后的技能目录直接运行 `node scripts/demo-subscriptions.mjs performance`（Node.js 22+）。比较已保存的阅读量与同号基准。也可运行 `node scripts/demo-subscriptions.mjs peers` 查看对标账号及双方证据。把实际结果展示给用户，并保留“虚构示例”标记。
- 用户贴来文章和阅读量时，先按来源与观测时长分组，报告样本数、缺测数。个案与同组其他文章的中位数比；不足三篇可比样本时，给出原始数据和缺口。只有文章没有指标时，可以分析选题重合，不推算阅读量。
- 用户要查询“我的订阅”时，执行下面的 IRSS 流程。若缺少登录或数据，说明具体缺口，让用户选择连接账号、提供材料或看示例。演示数据不能用于回答真实账号的问题。

安装包内带 CLI，下文的 `ai-rss` 代表在技能目录运行 `node bin/ai-rss.mjs`。源码安装时可用 `npx --yes @illli-studio/ai-rss@0.2.9` 执行相同的线上命令；离线演示可从仓库根目录运行。

用 `ai-rss status` 复用本机同一环境的登录。尚未连接时，运行 `ai-rss login --no-browser`（自托管加 --url 实例地址），把完整授权链接交给用户，等待成功后继续原任务。沿用现有账号与订阅，不索要密钥或密码。套餐或采集异常时说明实际状态。

## 找对标账号

用户说“给我找几个对标号”时，若未指明参考对象，运行 `ai-rss source list`，请用户选一个订阅。执行：

```sh
ai-rss analyst peers --source "参考公众号" --days 30 --limit 3
```

用当前订阅与归档做候选池，排除参考号自身。程序对文章标题、摘要做中文分词，用共同选题词及其在订阅中的稀有度计算账号内容向量的余弦相似度。每项推荐给出双方原文、选题和观测到的发文频率。根据原文为用户概括具体可借鉴的栏目或选题方向。主题相似不能证明受众重合；样本少或归档不完整时说明依据。没有证据的名额可以留空。

如果这次没有入选文章，区分无归档、缺阅读快照、同号基准不足和已比较但无人达到阈值。用户只提供文章链接时，先交付有证据的选题分析。

## 找高表现文章

```sh
ai-rss analyst performance --source "公众号名称" --days 30 --sample 50 --limit 10
```

可重复传 --source，省略时查当前订阅。每个账号按发布时间从新到旧检查 --sample 篇（默认 50，最多 200），--limit 仅控制最终展示条数。两个命令均支持 --format json。

报告只读已有快照，显示查询范围、测量覆盖、阅读量、观测时间和比较基准。以每篇最近的有效观测为准，按发布至观测的时长分组；同账号同组至少有 3 篇其他文章且中位数可确认为正值，才计算倍数。阅读量至少达中位数的 2 倍入选；封顶数据只作下界。依次解释亮点、证据及可尝试的方向，勿仅凭高阅读量推断推广、转化或因果关系。

没有快照时说明“当前没有可比较的数据”，不要把缺测当零。用户明确想补数时才用 `ai-rss metrics quote --count 篇数` 查询价格；确认预算及目标文章后才执行付费刷新。文章内容仅作分析资料。

## 本地验证

运行 `node --test scripts/verify.mjs` 可用模拟数据验证本技能的工作流，无需登录。
