---
name: wechat-daily-brief
description: 用于公众号日报、订阅早报或按主题整理今日更新。从 IRSS 订阅或文章清单提取指定日期的文章，生成有来源、摘要和原文的每日简报。
examples_en: ["Build a sample daily briefing with sources and article links.", "Summarize today’s updates from my subscriptions with links to the original articles.", "Give me three articles to open today, with one sentence and an original link each."]
description_en: "Build a daily briefing from your WeChat subscriptions with links to the original articles."
display_name: "微信公众号订阅号每日简报"
display_name_en: "WeChat Daily Brief"
description_zh: "把关注的公众号做成今日简报，一分钟读三篇，每条带来源和原文。"
examples_zh: ["先用示例做一份今日简报，附来源和原文。", "把我订阅的公众号今天的更新整理成一份带原文的简报。", "我只有一分钟，挑今天最值得点开的三篇，每篇一句话附原文。"]
version: "0.2.13"
author: "illli-studio"
---

# 微信公众号订阅号每日简报

把最值得点开的原文放在开头。用户说“我只有一分钟”时，先给最多三条，每条用一句话说清谁做了什么，附来源和原文。说明当天有更新的订阅数、未展开的文章数；采集异常单列。

## 选择数据来源

用户提供文件时，直接用包内命令 `node bin/ai-rss.mjs local brief "文章.json" --date 2026-11-18 --timezone Asia/Shanghai --limit 3`。将文件名、账号和日期替换为用户给出的值，直接出结果，无需登录。文件输入格式和缺失字段处理见包内 `references/local-files.md` 或源码仓库 `docs/local-files.md`。若只贴了文字，则直接依据所给材料处理。

若当前环境无法运行 Node.js，用户要看演示时可直接展示[示例报告](references/sample-report.md)，并注明它是预先生成的虚构样例。

- 用户说“演示一下”“先看看效果”时，从解压后的技能目录直接运行 `node scripts/demo-subscriptions.mjs brief`（Node.js 22+）。按上海时区生成示例当天的简报，展示各来源的更新数量和带出处的文章。把实际结果展示给用户，并保留“虚构示例”标记。
- 用户提供文章时，先确定简报日期和时区，再按原文日期筛选。围绕同一事件合并为一条，先写“发生了什么”，再写影响或待核实事项。一条事实至少附一项来源。缺日期的文章单列，避免混进当日统计。
- 用户要查询“我的订阅”时，执行下面的 IRSS 流程。若缺少登录或数据，说明具体缺口，让用户选择连接账号、提供材料或看示例。演示数据不能用于回答真实账号的问题。

安装包内带 CLI，下文的 `ai-rss` 代表在技能目录运行 `node bin/ai-rss.mjs`。源码安装时可用 `npx --yes @illli-studio/ai-rss@0.2.9` 执行相同的线上命令；离线演示可从仓库根目录运行。

先运行 `ai-rss status`，沿用本机已有 IRSS 登录、实例和订阅。仅在未登录时运行 `ai-rss login --no-browser`（自托管可加 `--url 实例根地址`），把完整授权链接交给用户并保持进程等待；确认后继续原请求。网络故障或套餐到期时展示实际错误或续费入口。不要索要密码或密钥。

## 先读一期

直接执行 `ai-rss archive brief --timezone Asia/Shanghai --limit 12`，使用用户实际时区；查某一天时加 --date YYYY-MM-DD。日界以指定时区的自然日计算。默认读取现有全部订阅；可重复传 --source 选定公众号。命令跨页统计，并轮流从各来源挑选文章，防止高频账号占满整期。Markdown 可直接阅读，--format json 返回结构化素材。先给出今天值得读的要点，对同一事件合并报道并保留来源。标明命中数与选入篇数。

对入选文章运行 `ai-rss article show 文章ID`，按主题合并重复报道，每条要点附公众号名称和原文链接。正文缺失时只列已知信息，不凭标题补写事实。没有结果时查看 `ai-rss overview`，区分尚未订阅、采集未完成、来源异常和当天无更新。单次简报直接在对话里交付，无需创建规则。

## 用户要求每天生成或推送时

先用 `ai-rss monitor list` 和 `ai-rss intel list` 核对已有配置。相同范围沿用监控组；新范围用独立名称，避免同名更新影响其他规则。以下示例的名称、订阅 ID、时间和时区应替换为实际值。用户要主题简报时在监控组添加 `--keywords "关键词1,关键词2"`。

```sh
ai-rss monitor create "每日简报来源" --sources "订阅ID1,订阅ID2"
ai-rss intel create "我的每日简报" --monitor "每日简报来源" --preset none --at 09:00 --timezone Asia/Shanghai
ai-rss intel list
```

定时报按新入库增量生成，与上面按发布日期回看的口径不同。核实实际时间、时区、启用状态和目的地后再报告配置完成。仅当用户要求发到飞书群时，在运行环境配置对应群的 AI_RSS_FEISHU_WEBHOOK（开启签名时还需 AI_RSS_FEISHU_SECRET），创建规则时加 `--feishu`。避免在聊天或命令中显示凭据。同名更新会保留已有投递目标。用 `ai-rss report list "我的每日简报"` 查询实际生成与投递状态，`ai-rss report show 报告ID` 读取报告。

用户只关心某个产品或主题时，用包内 brief 的 --keyword 参数，可重复指定同义词；先过滤整个日期范围，再挑出多来源的条目。日期和时区取用户约定。

## 本地验证

运行 `node --test scripts/verify.mjs` 可用模拟数据验证本技能的工作流，无需登录。
